# Kivora AI

Starter project untuk keyboard Android native.

Alur:
Splash/Intro -> Aktifkan Keyboard -> Pilih Kivora -> Keyboard

Tidak ada login akun.

Sudah tersedia:
- InputMethodService
- Android Keyboard Service declaration
- Indonesia + English subtype
- QWERTY keyboard
- Space / Backspace / Enter
- Tombol AI / Translate / Kamus / AI Reply / Shopping sebagai toolbar awal

Tahap berikutnya:
1. Theme Engine + tema animasi
2. Font Engine
3. Menu Bahasa lengkap
4. AI Write / Translate / Kamus / AI Reply
5. AI Shopping
6. UI 3D final


## Theme Engine
Native keyboard sekarang membaca tema dari KivoraThemeStore dan menyimpan pilihan secara lokal. Tema awal: Kivora Mint, Ocean Motion, Neon Pulse, Sakura Pop, Black Gold, Forest Motion.


## Expanded Theme Store
16 kategori dan 158 tema native, dengan flag LIVE untuk tema yang disiapkan sebagai animated/live. Theme Store menyimpan pilihan secara lokal dan keyboard membaca tema aktif.


## Font Store
Added separate Keyboard Font and Fancy Text systems. 22 modern font-family entries plus 30+ Gen-Z/fancy text styles across Trending, Cute, Dark, Elegant, Gaming/Cyber, Retro, and AI/Future.


## Build APK — Kivora AI

1. Buka folder project ini di Android Studio.
2. Pastikan Android SDK Platform 35 dan Build Tools terpasang.
3. Jalankan Gradle Sync.
4. Sambungkan HP Android atau gunakan emulator.
5. Run `app`.
6. Setelah native keyboard berhasil diuji: `Build > Generate App Bundle(s) / APK(s) > Generate APK(s)`.
7. APK debug akan berada di `app/build/outputs/apk/debug/`.
8. Untuk rilis publik, buat keystore sendiri dan gunakan `Generate Signed Bundle / APK`.
9. Untuk Google Play, gunakan Android App Bundle (`.aab`).

Catatan: fitur AI/Translate/Kamus/AI Reply/Shopping pada starter masih berupa fondasi UI/placeholder; jangan dianggap sebagai versi final sampai integrasi backend/API dan testing selesai.
