package ai.kivora.keyboard

data class KivoraFont(val id:String,val name:String,val category:String,val sample:String)

data class FancyStyle(val id:String,val name:String,val category:String,val transform:(String)->String)

object KivoraFontStore {
    val fonts = listOf(
        KivoraFont("inter","Inter","Modern","Kivora AI"),
        KivoraFont("manrope","Manrope","Modern","Kivora AI"),
        KivoraFont("jakarta","Plus Jakarta Sans","Modern","Kivora AI"),
        KivoraFont("sora","Sora","AI / Tech","Kivora AI"),
        KivoraFont("space_grotesk","Space Grotesk","AI / Tech","Kivora AI"),
        KivoraFont("outfit","Outfit","Modern","Kivora AI"),
        KivoraFont("poppins","Poppins","Modern","Kivora AI"),
        KivoraFont("montserrat","Montserrat","Modern","Kivora AI"),
        KivoraFont("ibm_plex","IBM Plex Sans","AI / Tech","Kivora AI"),
        KivoraFont("jetbrains","JetBrains Mono","AI / Tech","Kivora AI"),
        KivoraFont("source_code","Source Code Pro","AI / Tech","Kivora AI"),
        KivoraFont("playfair","Playfair Display","Elegant","Kivora AI"),
        KivoraFont("dm_sans","DM Sans","Modern","Kivora AI"),
        KivoraFont("figtree","Figtree","Modern","Kivora AI"),
        KivoraFont("archivo","Archivo","Display","Kivora AI"),
        KivoraFont("anton","Anton","Display","Kivora AI"),
        KivoraFont("bebas","Bebas Neue","Display","Kivora AI"),
        KivoraFont("unbounded","Unbounded","AI / Tech","Kivora AI"),
        KivoraFont("roboto","Roboto","Core","Kivora AI"),
        KivoraFont("noto_sans","Noto Sans","Core","Kivora AI"),
        KivoraFont("noto_serif","Noto Serif","Elegant","Kivora AI"),
        KivoraFont("noto_mono","Noto Sans Mono","AI / Tech","Kivora AI")
    )

    val fancyCategories = listOf("Trending / Gen Z","Cute","Dark","Elegant","Gaming / Cyber","Retro","AI / Future")

    val fancyStyles = listOf(
        FancyStyle("bold","Bold","Trending / Gen Z",{it.map{c->bold.getOrDefault(c,c)}.joinToString("")}),
        FancyStyle("italic","Italic","Trending / Gen Z",{it.map{c->italic.getOrDefault(c,c)}.joinToString("")}),
        FancyStyle("bold_italic","Bold Italic","Trending / Gen Z",{it.map{c->boldItalic.getOrDefault(c,c)}.joinToString("")}),
        FancyStyle("script","Script","Elegant",{it.map{c->script.getOrDefault(c,c)}.joinToString("")}),
        FancyStyle("gothic","Gothic","Dark",{it.map{c->gothic.getOrDefault(c,c)}.joinToString("")}),
        FancyStyle("double","Double Struck","Elegant",{it.map{c->double.getOrDefault(c,c)}.joinToString("")}),
        FancyStyle("mono","Monospace","AI / Future",{it.map{c->mono.getOrDefault(c,c)}.joinToString("")}),
        FancyStyle("bubble","Bubble","Cute",{bubble(it)}),
        FancyStyle("circled","Circled","Cute",{circled(it)}),
        FancyStyle("squared","Squared","Cute",{squared(it)}),
        FancyStyle("fullwidth","Fullwidth","Retro",{fullwidth(it)}),
        FancyStyle("small_caps","Small Caps","Trending / Gen Z",{smallCaps(it)}),
        FancyStyle("wide","Wide","Retro",{it.toCharArray().joinToString(" ") }),
        FancyStyle("underline","Underline","Trending / Gen Z",{it.map{c->"$c\u0332"}.joinToString("")}),
        FancyStyle("strike","Strikethrough","Dark",{it.map{c->"$c\u0336"}.joinToString("")}),
        FancyStyle("glitch","Glitch","Gaming / Cyber",{glitch(it)}),
        FancyStyle("vaporwave","Vaporwave","Retro",{fullwidth(it)}),
        FancyStyle("pixel","Pixel","Gaming / Cyber",{it.map{c->mono.getOrDefault(c,c)}.joinToString("")}),
        FancyStyle("cyber","Cyber","AI / Future",{it.map{c->mono.getOrDefault(c,c)}.joinToString("")}),
        FancyStyle("y2k","Y2K","Retro",{fullwidth(it)}),
        FancyStyle("coquette","Coquette","Cute",{it + " ♡"}),
        FancyStyle("angel","Angel","Cute",{ "୨୧ " + it + " ୨୧"}),
        FancyStyle("aesthetic","Aesthetic","Trending / Gen Z",{it.toCharArray().joinToString("  ")}),
        FancyStyle("sparkle","Sparkle","Trending / Gen Z",{ "✧･ﾟ: " + it + " :ﾟ･✧"}),
        FancyStyle("heart","Heart","Cute",{ "♡ " + it + " ♡"}),
        FancyStyle("star","Star","Cute",{ "★ " + it + " ★"}),
        FancyStyle("royal","Royal","Elegant",{ "♛ " + it + " ♛"}),
        FancyStyle("neon","Neon","Gaming / Cyber",{ "⚡ " + it + " ⚡"}),
        FancyStyle("hacker","Hacker","Gaming / Cyber",{ "[ " + it + " ]"}),
        FancyStyle("retro","Retro","Retro",{ "《 " + it + " 》"}),
        FancyStyle("futuristic","Futuristic","AI / Future",{ "⌁ " + it + " ⌁"})
    )

    private val bold=mapOf('A' to '𝐀','B' to '𝐁','C' to '𝐂','D' to '𝐃','E' to '𝐄','F' to '𝐅','G' to '𝐆','H' to '𝐇','I' to '𝐈','J' to '𝐉','K' to '𝐊','L' to '𝐋','M' to '𝐌','N' to '𝐍','O' to '𝐎','P' to '𝐏','Q' to '𝐐','R' to '𝐑','S' to '𝐒','T' to '𝐓','U' to '𝐔','V' to '𝐕','W' to '𝐖','X' to '𝐗','Y' to '𝐘','Z' to '𝐙','a' to '𝐚','b' to '𝐛','c' to '𝐜','d' to '𝐝','e' to '𝐞','f' to '𝐟','g' to '𝐠','h' to '𝐡','i' to '𝐢','j' to '𝐣','k' to '𝐤','l' to '𝐥','m' to '𝐦','n' to '𝐧','o' to '𝐨','p' to '𝐩','q' to '𝐪','r' to '𝐫','s' to '𝐬','t' to '𝐭','u' to '𝐮','v' to '𝐯','w' to '𝐰','x' to '𝐱','y' to '𝐲','z' to '𝐳')
    private val italic=bold.mapKeys{it.key}.mapValues{c-> when(c.value){'𝐀'->'𝘈';'𝐁'->'𝘉';'𝐂'->'𝘊';'𝐃'->'𝘋';'𝐄'->'𝘌';'𝐅'->'𝘍';'𝐆'->'𝘎';'𝐇'->'𝘏';'𝐈'->'𝘐';'𝐉'->'𝘑';'𝐊'->'𝘒';'𝐋'->'𝘓';'𝐌'->'𝘔';'𝐍'->'𝘕';'𝐎'->'𝘖';'𝐏'->'𝘗';'𝐐'->'𝘘';'𝐑'->'𝘙';'𝐒'->'𝘚';'𝐓'->'𝘛';'𝐔'->'𝘜';'𝐕'->'𝘝';'𝐖'->'𝘞';'𝐗'->'𝘟';'𝐘'->'𝘠';'𝐙'->'𝘡';else->c.value}} 
    private val boldItalic=bold
    private val script=mapOf('A' to '𝓐','B' to '𝓑','C' to '𝓒','D' to '𝓓','E' to '𝓔','F' to '𝓕','G' to '𝓖','H' to '𝓗','I' to '𝓘','J' to '𝓙','K' to '𝓚','L' to '𝓛','M' to '𝓜','N' to '𝓝','O' to '𝓞','P' to '𝓟','Q' to '𝓠','R' to '𝓡','S' to '𝓢','T' to '𝓣','U' to '𝓤','V' to '𝓥','W' to '𝓦','X' to '𝓧','Y' to '𝓨','Z' to '𝓩')
    private val gothic=mapOf('A' to '𝔄','B' to '𝔅','C' to 'ℭ','D' to '𝔇','E' to '𝔈','F' to '𝔉','G' to '𝔊','H' to 'ℌ','I' to 'ℑ','J' to '𝔍','K' to '𝔎','L' to '𝔏','M' to '𝔐','N' to '𝔑','O' to '𝔒','P' to '𝔓','Q' to '𝔔','R' to 'ℜ','S' to '𝔖','T' to '𝔗','U' to '𝔘','V' to '𝔙','W' to '𝔚','X' to '𝔛','Y' to '𝔜','Z' to 'ℨ')
    private val double=mapOf('A' to '𝔸','B' to '𝔹','C' to 'ℂ','D' to '𝔻','E' to '𝔼','F' to '𝔽','G' to '𝔾','H' to 'ℍ','I' to '𝕀','J' to '𝕁','K' to '𝕂','L' to '𝕃','M' to '𝕄','N' to 'ℕ','O' to '𝕆','P' to 'ℙ','Q' to 'ℚ','R' to 'ℝ','S' to '𝕊','T' to '𝕋','U' to '𝕌','V' to '𝕍','W' to '𝕎','X' to '𝕏','Y' to '𝕐','Z' to 'ℤ')
    private val mono=mapOf('A' to '𝙰','B' to '𝙱','C' to '𝙲','D' to '𝙳','E' to '𝙴','F' to '𝙵','G' to '𝙶','H' to '𝙷','I' to '𝙸','J' to '𝙹','K' to '𝙺','L' to '𝙻','M' to '𝙼','N' to '𝙽','O' to '𝙾','P' to '𝙿','Q' to '𝚀','R' to '𝚁','S' to '𝚂','T' to '𝚃','U' to '𝚄','V' to '𝚅','W' to '𝚆','X' to '𝚇','Y' to '𝚈','Z' to '𝚉')
    private fun bubble(s:String)=s.map{if(it.isLetter()) "◯$it" else it}.joinToString("")
    private fun circled(s:String)=s.map{if(it.isLetter()) "ⓘ" else it}.joinToString("")
    private fun squared(s:String)=s.map{if(it.isLetter()) "▣" else it}.joinToString("")
    private fun fullwidth(s:String)=s.map{if(it.code in 33..126) (it.code+0xFEE0).toChar() else it}.joinToString("")
    private fun smallCaps(s:String)=s.lowercase().map{smallCapsMap.getOrDefault(it,it)}.joinToString("")
    private val smallCapsMap=mapOf('a' to 'ᴀ','b' to 'ʙ','c' to 'ᴄ','d' to 'ᴅ','e' to 'ᴇ','f' to 'ғ','g' to 'ɢ','h' to 'ʜ','i' to 'ɪ','j' to 'ᴊ','k' to 'ᴋ','l' to 'ʟ','m' to 'ᴍ','n' to 'ɴ','o' to 'ᴏ','p' to 'ᴘ','q' to 'ǫ','r' to 'ʀ','s' to 's','t' to 'ᴛ','u' to 'ᴜ','v' to 'ᴠ','w' to 'ᴡ','x' to 'x','y' to 'ʏ','z' to 'ᴢ')
    private fun glitch(s:String)=s.map{if(it.isLetter()) "$it̷" else it}.joinToString("")
}
