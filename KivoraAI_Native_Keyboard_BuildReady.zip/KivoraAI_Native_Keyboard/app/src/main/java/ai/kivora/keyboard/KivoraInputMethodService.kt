package ai.kivora.keyboard

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout

class KivoraInputMethodService : InputMethodService() {

    private lateinit var theme: KivoraTheme

    override fun onCreateInputView(): View {
        theme = KivoraThemeStore.current(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(6, 6, 6, 6)
            setBackgroundColor(theme.background)
        }

        val toolbar = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf("✨ AI", "🌐", "📚", "💬", "🛍️").forEach { label ->
            toolbar.addView(key(label, 0.2f) {})
        }
        root.addView(toolbar)

        listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM").forEach { row ->
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER }
            row.forEach { c ->
                line.addView(key(c.toString(), 0.1f) {
                    currentInputConnection?.commitText(c.toString().lowercase(), 1)
                })
            }
            root.addView(line)
        }

        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottom.addView(key("😊", .12f) {})
        bottom.addView(key("🌐", .12f) {})
        bottom.addView(key("Space", .42f) {
            currentInputConnection?.commitText(" ", 1)
        })
        bottom.addView(key("⌫", .12f) {
            currentInputConnection?.deleteSurroundingText(1, 0)
        })
        bottom.addView(key("↵", .12f) {
            currentInputConnection?.sendKeyEvent(
                android.view.KeyEvent(
                    android.view.KeyEvent.ACTION_DOWN,
                    android.view.KeyEvent.KEYCODE_ENTER
                )
            )
        })
        root.addView(bottom)

        return root
    }

    private fun key(label: String, weight: Float, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = if (label.length > 1) 10f else 13f
            isAllCaps = false
            setTextColor(theme.keyText)
            background = GradientDrawable().apply {
                setColor(theme.key)
                cornerRadius = 14f
                setStroke(1, Color.argb(35, 0, 0, 0))
            }
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, 52.dp(), weight).apply {
                setMargins(3, 3, 3, 3)
            }
        }
    }

    private fun Int.dp(): Int =
        (this * resources.displayMetrics.density).toInt()
}
