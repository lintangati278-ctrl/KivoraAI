package ai.kivora.keyboard

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.LinearLayout
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 60, 28, 28)
            setBackgroundColor(Color.rgb(248, 255, 255))
        }

        val title = TextView(this).apply {
            text = "⌨️  Kivora AI"
            textSize = 30f
            setTextColor(Color.rgb(20, 175, 172))
        }
        val subtitle = TextView(this).apply {
            text = "\nKeyboard AI • Theme • Font • Bahasa\n\nTidak membutuhkan login akun."
            textSize = 16f
            setTextColor(Color.DKGRAY)
        }
        val enable = Button(this).apply {
            text = "Aktifkan Kivora Keyboard"
            setOnClickListener {
                startActivity(Intent("android.settings.INPUT_METHOD_SETTINGS"))
            }
        }
        val choose = Button(this).apply {
            text = "Pilih Kivora sebagai Keyboard"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(enable)
        root.addView(choose)
        setContentView(root)
        val themeStore = Button(this).apply { text = "🎨 Theme Store"; setOnClickListener { showThemeStore() } }
        (findViewById<LinearLayout>(android.R.id.content)?.getChildAt(0) as? LinearLayout)?.addView(themeStore)
    }


    private fun showThemeStore() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val title = TextView(this).apply {
            text = "Kivora AI • Theme Store"
            textSize = 24f
            setPadding(0, 0, 0, 20)
        }
        box.addView(title)
        for (category in KivoraThemeStore.categories) {
            val header = TextView(this).apply {
                text = category
                textSize = 18f
                setPadding(0, 18, 0, 8)
            }
            box.addView(header)
            for (theme in KivoraThemeStore.byCategory(category)) {
                val b = Button(this).apply {
                    text = theme.name + if (theme.animated) "  ✨ LIVE" else ""
                    setOnClickListener {
                        KivoraThemeStore.select(this@MainActivity, theme.id)
                        title.text = "Applied: ${theme.name}"
                    }
                }
                box.addView(b)
            }
        }
        scroll.addView(box)
        setContentView(scroll)
    }

}
